$:.unshift File.dirname(__FILE__)

require "textorize/runner"
require "textorize/renderer"
require "textorize/saver"
require "textorize/color"